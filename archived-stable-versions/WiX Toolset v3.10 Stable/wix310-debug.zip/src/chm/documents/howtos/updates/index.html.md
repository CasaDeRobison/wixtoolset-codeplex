---
title: How To: Updates
layout: documentation
---
# How To: Updates
This section includes guides for building updates for your installer.

* [How To: Implement a major upgrade in your installer](major_upgrade.html)
