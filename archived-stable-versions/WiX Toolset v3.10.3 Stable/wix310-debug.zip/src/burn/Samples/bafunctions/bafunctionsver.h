// Copyright (c) .NET Foundation and contributors. All rights reserved. Licensed under the Microsoft Reciprocal License. See LICENSE.TXT file in the project root for full license information.

#ifndef _VERSION_FILE_H_
#define _VERSION_FILE_H_

#define szVerMajorMinor "1.0"
#define szVerMajorMinorBuildRev "1.0.0.0"
#define rmj	1
#define rmm	0
#define rbd	0
#define rev	0

#endif
