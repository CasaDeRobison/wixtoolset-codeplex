---
title: Using WiX Standard Bootstrapper Application Variables
layout: documentation
after: wixstdba_customize
---
# Using WiX Standard Bootstrapper Application Variables

The WiX Standard Bootstrapper Application offers a set of variables:

* WixBundleFileVersion - gets the file version of the bundle .exe.
* WixStdBALanguageId - gets the language in effect for the WixStdBA user interface.

