// Copyright (c) .NET Foundation and contributors. All rights reserved. Licensed under the Microsoft Reciprocal License. See LICENSE.TXT file in the project root for full license information.

#include "precomp.h"

// warning LNK4221: 
// This object file does not define any previously undefined public symbols,
// so it will not be used by any link operation that consumes this library.
#pragma warning(disable : 4221)
