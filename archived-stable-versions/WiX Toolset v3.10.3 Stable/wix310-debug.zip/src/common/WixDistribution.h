#pragma once
// Copyright (c) .NET Foundation and contributors. All rights reserved. Licensed under the Microsoft Reciprocal License. See LICENSE.TXT file in the project root for full license information.


#ifndef __WIXDISTRIBUTION_FILE_H_
#define __WIXDISTRIBUTION_FILE_H_

#define VER_COMPANY_NAME    ".NET Foundation"
#define VER_LEGAL_COPYRIGHT "Copyright (c) .NET Foundation and contributors.\240 All rights reserved."
#define VER_PRODUCT_NAME    "Windows Installer XML Toolset"

#endif // __WIXDISTRIBUTION_FILE_H_
