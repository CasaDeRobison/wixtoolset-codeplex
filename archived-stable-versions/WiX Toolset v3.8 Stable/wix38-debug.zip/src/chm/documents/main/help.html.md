---
title: Getting Help
layout: documentation
after: wix_learning
---
# Getting Help

Please see <a href="http://wixtoolset.org/" target="_blank">http://wixtoolset.org/</a> for more information about the WiX toolset. This site includes the following information:

1. Links to download weekly releases of the WiX toolset.
1. The WiX bug database where you can report new bugs or check the status of existing bugs.
1. <a href="http://wix.sourceforge.net/mailinglists.html" target="_blank">Mailing lists</a> to ask questions, make suggestions or discuss the WiX toolset with other users and the WiX developers.
1. Links to blogs maintained by the WiX developers.
