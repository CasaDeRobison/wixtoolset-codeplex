---
title: Useful Windows Installer Information
layout: documentation
after: codepage
---

# Useful Windows Installer Information

Link to the Windows Installer 4.5 SDK: <http://msdn.microsoft.com/en-us/library/aa372866.aspx>

List of Windows Installer default properties: <http://msdn.microsoft.com/en-us/library/aa370905.aspx>

List of Windows Installer operators for conditional expressions: <http://msdn.microsoft.com/en-us/library/aa368012.aspx>
