﻿
using System.Reflection;

[assembly: AssemblyDescription("Simple command-line CAB/ZIP packing and unpacking tool.")]
