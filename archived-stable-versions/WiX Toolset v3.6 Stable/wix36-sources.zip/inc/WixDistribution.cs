using System.Reflection;
using System.Resources;

[assembly: AssemblyCompany("Outercurve Foundation")]
[assembly: AssemblyCopyright("Copyright � Outercurve Foundation. All rights reserved.")]
[assembly: AssemblyTrademark("")]
#if DEBUG
    [assembly: AssemblyConfiguration("DEBUG")]
#else
    [assembly: AssemblyConfiguration("")]
#endif
[assembly: NeutralResourcesLanguage("en-US")]
[assembly: AssemblyProduct("Windows Installer XML")]
